(function ($) {
    $(document).keydown(function (e) {
        if (e.ctrlKey && e.key == 's') {
            console.log("auto heading numbering ...");
            numbering();
        }
    });

    function numbering() {
        var levels = [
            { ordinal: 0 },
            { ordinal: 0 },
            { ordinal: 0 },
            { ordinal: 0 },
            { ordinal: 0 },
            { ordinal: 0 },
        ];
        var previous = null;
        $('#write *[mdtype=heading]').toArray().forEach((heading) => {
            var current = {
                level: heading.tagName.substring(1),
            };
            var span = $(heading).find('span');
            var title = span.text().trim();
            var match = title.match(/^((?:\d+.)*\d+、)(.*)/);
            if (match) {
                title = match[2];
            }

            if (previous) {
                if (current.level > previous.level) {
                    levels.forEach((v, i) => {
                        if (previous.level - 1 < i && i <= current.level - 1) {
                            levels[i].ordinal = 0;
                        }
                    });
                }
            }

            levels[current.level - 1].ordinal++;


            var prefix = levels.filter((v, i) => i < current.level).map(v => v.ordinal).join('.') + '、';
            span.text(prefix + title);
            span.trigger('input');

            previous = current;
        });
    }

    console.log("auto heading numbering installed!");
})(jQuery);